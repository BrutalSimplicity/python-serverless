from . import yaml_reader

parse_yaml = yaml_reader.parse_yaml
